<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('navbar'); ?>



<?php echo $__env->make('FrontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seedsofhope\resources\views/FrontEnd/donate.blade.php ENDPATH**/ ?>