*********Installation and Running*********
Ensure that you first locate the database sql file named; laravelblog.sql and install in your local server
Once the database is setup, proceed with signing in

******Credentials******
Username: *Create your own*
Password: *Create your own*

******Disclaimer******
The super admin only has the right to add other users to the system.
